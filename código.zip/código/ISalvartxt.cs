public interface ISalvartxt{
    public void Salvartxt();
    
}
