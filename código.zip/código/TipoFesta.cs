using System;

namespace POOCasamentosECia
{
    internal enum TipoFesta
    {
        CASAMENTO,
        FORMATURA,
        FESTA_DE_EMPRESA,
        FESTA_DE_ANIVERSARIO,
        LIVRE,
    }
}
