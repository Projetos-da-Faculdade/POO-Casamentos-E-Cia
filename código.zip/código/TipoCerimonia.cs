using System; 

namespace POOCasamentosECia
{
    internal enum TipoCerimonia
    {
        STANDARD, 
        LUXO,
        PREMIER
    }
}
