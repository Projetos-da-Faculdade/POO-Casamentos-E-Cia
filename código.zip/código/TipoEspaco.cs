using System;

namespace POOCasamentosECia
{
    internal enum TipoEspaco
    {
        ESPACO_A,
        ESPACO_B,
        ESPACO_C,
        ESPACO_D,
        ESPACO_E,
        ESPACO_F,
        ESPACO_G,
        ESPACO_H
    }
}
