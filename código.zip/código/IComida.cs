using POOCasamentosECia;

interface IComida
{
    public double DefinirPrecoComida(int quantidadeConvidados);
}
