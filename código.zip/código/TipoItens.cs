using System;

namespace POOCasamentosECia
{
    internal enum TipoItens
    {
        ITENS_MESA,
        DECORACAO,
        BOLO, 
        MUSICA 
    }
}
