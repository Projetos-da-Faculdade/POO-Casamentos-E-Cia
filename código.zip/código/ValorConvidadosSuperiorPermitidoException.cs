public class ValorConvidadosSuperiorPermitidoException : Exception{
    public ValorConvidadosSuperiorPermitidoException(){}
    public ValorConvidadosSuperiorPermitidoException(string message) : base(message){}
    public ValorConvidadosSuperiorPermitidoException(string message, Exception innerException) : base(message, innerException){}
}
