using System;
namespace FestaEcia
{
    internal enum TipoBebida
    {
        AGUA_SEM_GAS, 
        SUCO, 
        REFRIGERANTE, 
        CERVEJA_COMUM, 
        CERVEJA_ARTESANAL,
        ESPUMANTE_NACIONAL, 
        ESPUMANTE_IMPORTADO
    }
}