public class VerificaSextaSabadoException : Exception{
    public VerificaSextaSabadoException(){}
    public VerificaSextaSabadoException(string message) : base(message){}
    public VerificaSextaSabadoException(string message, Exception innerException) : base(message, innerException){}
}