using System;

namespace POOCasamentosECia
{
    interface IInformacaoFesta
    {
        public void InformacaoFesta(); 
    }
}
